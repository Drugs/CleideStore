<?php
var_dump ($_GET);

$server = "localhost";
$user = "root";
$password = "";
$database = "test";
$id = $_GET["id"];

$connection = mysqli_connect($server, $user, $password, $database);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar " . mysqli_connect_error();
    exit();
}


$delete= "DELETE FROM cliente WHERE id='{$id}'";

mysqli_query($connection, $delete);

$_GET['status'] = 1;

if (isset($_GET['status'])){
    
    header ("Location: index.php?confirmacao={$_GET['status']}"); 
};


?>