<?php
var_dump ($_GET);

$server = "localhost";
$user = "root";
$password = "";
$database = "test";
$nome = $_GET["nome"];
$email = $_GET["email"];
$endereco = $_GET["endereco"];
$cpf = $_GET["cpf"];
$data = $_GET["date"];
$id = $_GET["id"];

$connection = mysqli_connect($server, $user, $password, $database);

if (mysqli_connect_errno()) {
    echo "Falha ao conectar " . mysqli_connect_error();
    exit();
}



$querry= "UPDATE cliente SET email='{$email}', data='{$data}', cpf='{$cpf}', endereco='{$endereco}',nome='{$nome}' WHERE id='{$id}'";

mysqli_query($connection, $querry);

$_GET['status'] = 2;

if (isset($_GET['status'])){
    
    header ("Location: index.php?confirmacao={$_GET['status']}"); 
};

?>